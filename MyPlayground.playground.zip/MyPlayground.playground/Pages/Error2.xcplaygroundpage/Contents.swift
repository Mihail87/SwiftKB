/*:
 ## I couldn’t ‘control Drag’ from the storyboard to create Outlets for a label of a cell
 [Dev KB](Dev%20KB) > Errors & Issues >
 
 > Apparently you need to complete the **‘Class’ attribute in the storyboard**, and you can then control Drag to that file which describes the Class. I was confused because the Reuse Identifier was the same…
 > Another time I was actually dragging to the interface file - instead of the proper Cell file.
 */
