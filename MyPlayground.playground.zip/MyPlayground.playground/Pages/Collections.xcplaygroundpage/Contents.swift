/*:
 ## Collections
 [Dev KB](Dev%20KB) > Data Structures
 * [Strings](Strings)
 * [Arrays](Arrays)
 * [Dictionary](Dictionary)
*/
